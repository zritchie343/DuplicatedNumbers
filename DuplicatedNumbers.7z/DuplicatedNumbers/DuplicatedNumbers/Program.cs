﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DuplicatedNumbers
{
    public class Program
    {
        public static int repeat = 0;

        static void Main(string[] args)
        {
            LinkedList<int> Champs = new LinkedList<int>();
            int userNumber = 0;
            bool exit = false;

            do
            {
                userNumber = ListSize();

                Champs = GenerateFirstList(userNumber);

                GenerateNewNumbers(Champs);

                PrintNumbers(Champs);

            } while (exit == false);
        }

        public static int ListSize()
        {
            bool result = false;
            bool result2 = false;
            int y1 = 0;
            int y2 = 0;
            string x2 = "";

            do
            {
                Console.WriteLine("Enter list size or e to exit");
                string x1 = Console.ReadLine();
                result = Int32.TryParse(x1, out y1);

                if (!result)
                {
                    Console.WriteLine("Not a number or too large");
                }
                if ((x1 == "e") || (x1 == "E"))
                {
                    Environment.Exit(0);
                }
                if ((x1 == "1") || (x1 == "2"))
                {
                    Console.WriteLine("Number needs to be larger");
                    result = false;
                }
            } while (result == false);

            do
            {
                Console.WriteLine("Enter how many repeat numbers you want or e to exit");
                x2 = Console.ReadLine();
                result2 = Int32.TryParse(x2, out y2);

                if (!result2)
                {
                    Console.WriteLine("Not a number or too large");
                }
                if ((x2 == "e") || (x2 == "E"))
                {
                    Environment.Exit(0);
                }
            } while (result2 == false);

            Console.WriteLine("");
            repeat = Convert.ToInt32(x2);
            
            return y1;
        }

        //Genrates a list of numbers based on users input
        public static LinkedList<int> GenerateFirstList(int NumberOfNumbers)
        {
            LinkedList<int> Champs = new LinkedList<int>();

            for (int i = 1; i <= NumberOfNumbers; i++)
            {
                Champs.AddFirst(i);
            }

            return Champs;
        }

        // This method randomly duplicates new numbers withing the set that exist
        public static LinkedList<int> GenerateNewNumbers(LinkedList<int> listOfAllNumbers)
        {
            Random r = new Random();
            //System.Threading.Thread.Sleep(10000);

            //Duplicates existing #s = to what ever "i" is less than
            for (int i = 0; i <= repeat; i++)
            {
                LinkedListNode<int> temp = listOfAllNumbers.First;

                int NewNumber = r.Next(1, listOfAllNumbers.Count);

                //set newNumber = temp
                for (int j = 0; j < NewNumber; j++)
                {
                    temp = temp.Next;
                }

                //puts temp next to the number thats the same as temp
                foreach (var value in listOfAllNumbers)
                {
                    if (temp.Value == value)
                    {
                        listOfAllNumbers.AddAfter(temp, value);
                        break;
                    }
                }
            }

            return listOfAllNumbers;
        }

        public static void PrintNumbers(LinkedList<int> listOfAllNumbers)
        {
            LinkedListNode<int> temp2 = listOfAllNumbers.First;
            temp2 = temp2.Next;

            foreach (var value in listOfAllNumbers)
            {
                if (temp2.Value == value)
                {
                    Console.Write(value + " ");
                }
                else
                {
                    Console.WriteLine(value);
                }

                if (temp2.Next != null)
                {
                    temp2 = temp2.Next;
                }
            }
            Console.WriteLine("");
            Console.ReadLine();
        }
    }
}
